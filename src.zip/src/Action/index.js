import movies from './Movies/movies';


export default {
    movies
}
