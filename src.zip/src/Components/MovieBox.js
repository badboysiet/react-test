import React from 'react';

function MovieBox(props) {
    return (
        <div>
            
        </div>
    );
}

export default MovieBox;