import React, { useEffect } from 'react';

const Upcoming = (props) => {
    useEffect(() => {
       console.log('Upcoming Api call')
    },[])
    return (
        <div>
            Upcoming
        </div>
    );
}

export default Upcoming;