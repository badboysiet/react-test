import Popular from "./Popular";
import Upcoming from "./Upcoming";

export {Popular,Upcoming };


